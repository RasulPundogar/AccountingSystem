/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

/**
 *
 * @author Happi6
 */
public class Employee {
    private String id;
    private String name;
    private String username;
    private String password;
    
    public Employee(){
        
    }    
    
    public void deductions(){
    
    }
    
    public void net_pay(){
        
    }
}
